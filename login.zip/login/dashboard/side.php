<?php
  $select_username = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
  $select_username->execute([$admin_id]);
  $fetch_username = $select_username->fetch(PDO::FETCH_ASSOC);
?>

<nav>
    <div class="logo">
        <div class="logos">
           <img src="../img/logo.png">
           <span class="town">Towntech Innvation</span>
        </div>
        <i class="fa-solid fa-times closed"></i>
    </div>
    <ul>
        <div class="ava">
           <img class="avatar big" name="old_file" src="../uploads/<?php echo $fetch_username["profile"] ?>">
            <div class="user">
                 <p><?php echo $fetch_username['username'];?></p>
             </div> 
        </div>
        <span class="opac">Main</span>
        <li>
            <a href="../dashboard/dash.php">
                <span class="icon"><i class="fa-solid fa-cube"></i></span>
                <span class="text">Dashboard</span>
            </a>
        </li>
        <span class="opac">Admin</span>
        <li>
            <a href="../passcode/passcode.php">
                <span class="icon"><i class="fa-solid fa-user-tie"></i></span>
                <span class="text">Admin</span>
            </a>
        </li>
    </ul>
</nav>


